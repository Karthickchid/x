// -----------------------------------------------------------------------------
// TreeSetExample.java
// -----------------------------------------------------------------------------

import java.util.Set;
import java.util.TreeSet;
import java.util.Iterator;

/**
 * -----------------------------------------------------------------------------
 * Used to provide an example of storing and retrieving objects from a
 * TreeSet container.
 * -----------------------------------------------------------------------------
 */

public class TreeSetExample {


    /**
     * Provides an example of how to work with the TreeSet container.
     */
    public static void doTreeSetExample() {

        final int MAX = 10;

        System.out.println("+--------------------------------------------------+");
        System.out.println("| Create/Store objects in a TreeSet container.     |");
        System.out.println("+--------------------------------------------------+");
        System.out.println();

        Set ss = new TreeSet();

        for (int i = 0; i < MAX; i++) {
            System.out.println("  - Storing Integer(" + i + ")");
            ss.add(new Integer(i));
        }
        ss.add((Object)"Melody");
        ss.add("Jeff");
        ss.add("Alex");

        System.out.println();
        System.out.println("+----------------------------------------------------------------+");
        System.out.println("| Retrieve objects in a TreeSet container using an Iterator.     |");
        System.out.println("+----------------------------------------------------------------+");
        System.out.println();

        Iterator i = ss.iterator();
        while (i.hasNext()) {
            System.out.println(i.next());
        }

    }


    /**
     * Sole entry point to the class and application.
     * @param args Array of String arguments.
     */
    public static void main(String[] args) {
        doTreeSetExample();
    }

}

import java.util.*;

public class MapExample 
{
  public static void main(String args[]) 
  {
    Map map = new HashMap();
    Integer val[] = new Integer[args.length];
    for (int i=0, n=args.length; i<n; i++) 
    {
      String key = args[i];
      val[i] = new Integer(i);
      Integer frequency = (Integer)map.get(key);
      if (frequency == null) 
      {
        frequency = val[i];
      } 
      
      map.put(key, frequency);
    }
    System.out.println("Hash Map : "+map);
    System.out.println("KEY\t VALUE");
    for(int i=0;i<args.length;i++)
	System.out.println(args[i]+"\t"+map.get(args[i]));
   }
}
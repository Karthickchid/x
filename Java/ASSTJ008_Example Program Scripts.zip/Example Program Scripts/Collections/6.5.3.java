import java.util.*;

public class TreeSetEx
{
	public static void main(String args[])
	{
		TreeSet ts = new TreeSet();
		ts.add("kris");
		ts.add("rama");
		ts.add("ananth");
		ts.add("ravi");
		Iterator i = ts.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());
		}

	}
}
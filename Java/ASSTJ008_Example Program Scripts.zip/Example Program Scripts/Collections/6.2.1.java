import java.util.*;

public class HashMapEx
{
	public static void main(String args[])
	{

		HashMap ht = new HashMap();
		ht.put("kris","ananth");
		ht.put("ravi","rama");
		ht.put("anand","kumar");
		ht.put("kris","kumar");
		Set s = ht.keySet();

		// Collection e=ht.values();
		Iterator  i = s.iterator();


		while(i.hasNext())
		{
			String key =(String)i.next();
			System.out.println(key+" mapped with value "+ht.get(key));
		}


	}
}
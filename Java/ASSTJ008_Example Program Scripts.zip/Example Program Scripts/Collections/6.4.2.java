import java.util.*;

public class StackEx
{
public static void main(String args[])
	{

		String str1 = "kris1";
		String str2 = "kris2";
		String str3 = "kris3";
		String str4 = "kris4";
		String str5 = "kris5";

		Stack st = new Stack();

		st.push(str1);
		st.push(str2);
		st.push(str3);
		st.push(str4);
		st.push(str5);

		System.out.println(st.pop());
		System.out.println(st.pop());
		System.out.println(st.peek());
		System.out.println(st.peek());
		System.out.println(st.search(str3));


	}
}
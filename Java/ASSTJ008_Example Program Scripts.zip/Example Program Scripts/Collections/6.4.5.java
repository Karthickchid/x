import java.util.*;


public class PropertiesEx
{
	public static void main(String args[])
	{
		Properties pro=System.getProperties();
		Enumeration e = pro.propertyNames();
		while(e.hasMoreElements())
		{
			String key = (String)e.nextElement();
			System.out.println(key+"---- "+pro.getProperty(key));
		}

	}
}
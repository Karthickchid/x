import java.util.*;

public class StringTokenizerEx
{
	public static void main(String args[])
	{
			String str = "This is a string for Test Purpose";
			StringTokenizer st = new StringTokenizer(str,"s");
			while(st.hasMoreElements())
			{
				System.out.println(st.nextElement());
			}
	}
}
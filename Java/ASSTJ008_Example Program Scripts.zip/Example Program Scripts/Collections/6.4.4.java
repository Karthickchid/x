import java.util.*;

public class TimerEx
{
	public static void main(String args[])
	{
		Timer t = new Timer();
		TestTask tt = new TestTask();
		t.schedule(tt,500);
	}
}

class TestTask extends TimerTask
{
	public void run()
	{
		for(int i=0;i<10;i++)
		{
			System.out.println(i);
			try{
				Thread.sleep(500);
			   }catch(Exception e){}
		}
	}
}

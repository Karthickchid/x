// -----------------------------------------------------------------------------
// PredicateTest.java
// -----------------------------------------------------------------------------

import java.util.List;
import java.util.LinkedList;
import java.util.Iterator;

/**
 * -----------------------------------------------------------------------------
 * The following class provides an example of how to use the PredicateIterator
 * and Predicate interface.
 * -----------------------------------------------------------------------------
 */

public class PredicateTest {

    static Predicate pred = new Predicate() {
        public boolean predicate(Object o) {
            return o.toString().startsWith("Hunter");
        }
    };

    public static void main(String[] args) {
        List list = new LinkedList();
        list.add("Hunter, Alex");
        list.add("Miller, Scott");
        list.add("Hunter, Melody");
        list.add("Fox, Eric");
        list.add("Johnson, Jack");
        list.add("Hunter, Jeff");

        Iterator iter  = list.iterator();
        Iterator iter2 = new PredicateIterator(iter, pred);
        while (iter2.hasNext()) {
            System.out.println(iter2.next());
        }
    }
}

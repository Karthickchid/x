import java.util.*;

public class HashSetEx
{
	public static void main(String args[])
	{

		HashSet hs = new HashSet();
		hs.add("kris");
		hs.add("kris1");
		hs.add("kris2");
		hs.add("kris3");
		hs.add("kris2");
		hs.add("kris3");
		Iterator i=hs.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());
		}
	}
}
import java.util.*;

public class TreeMapEx
{
	public static void main(String args[])
	{
		TreeMap tm = new TreeMap();
		tm.put("kris","ananth");
		tm.put("ravi","rama");
		tm.put("anand","kumar");
		tm.put("kris","kumar");

		Set s  = tm.keySet();
		Iterator i = s.iterator();
		while(i.hasNext())
		{
			String key=(String)i.next();
			System.out.println(key+"------"+tm.get(key));
		}



	}
}
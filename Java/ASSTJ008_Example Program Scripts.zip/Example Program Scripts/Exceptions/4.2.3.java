// Demonstrate throw.
class ThrowDemo 
{
	public static void main(String args[]) 
	{
		try {
			throw new NullPointerException("demo");
		} 
		catch(NullPointerException e) 
		{
			System.out.println("Null pointer exception caught : "+e);
		}
	}
}
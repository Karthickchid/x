// Demonstrate Userdefined Exception

class AgeLimitException extends Exception
{
	AgeLimitException(String msg)
	{
		super(msg);
	}
}

public class UserDefinedException 
{
	public static void main(String []args)
	{
		int age;

		try {
			age = 40;
			if(age>30)
				throw new AgeLimitException("Age should be less than 30");
		} catch(AgeLimitException e)
		{
			System.out.println(e);
		}
	}
}

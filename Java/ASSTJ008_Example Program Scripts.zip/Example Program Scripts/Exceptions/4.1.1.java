
class CheckedDemo
{
	public static void main(String args[]) 
	{
		throw  new  ClassNotFoundException("demo");
	//	System.out.println("After throw");
	}
}


class UncheckedDemo
{
	public static void main(String args[]) 
	{
		throw new RuntimeException("demo");
	//	System.out.println("After throw");
	}
}

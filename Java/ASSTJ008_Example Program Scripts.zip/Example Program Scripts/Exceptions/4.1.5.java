// Demonstrate finally.

class FinallyDemo 
{
	public static void main(String args[]) 
	{
		try {
			throw new RuntimeException("demo");
		}	 
		catch (Exception e) 
		{
			System.out.println("Exception caught");
		}
		finally 
		{
			System.out.println("In finally");
		}
		System.out.println("After try/catch/finally block");
	}
}

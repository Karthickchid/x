public class Exc0
{
        public static void main(String []args)
        {
                int d=0;
                int a=42/d;
        }
}

//Demonstrate Multiple catch statements

public class MultiCatch
{
        public static void main(String []args)
        {
		try {
			int a = args.length;
			System.out.println("a = "+a);
			int b = 42 / a;
			int c[] = { 1 };
			c[42] = 99;
		}
		catch(ArithmeticException e)
		{
			System.out.println("Divide By 0: "+e);
		}				
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("Out of bounds : "+e);
		}

		System.out.println("After try/catch blocks");
        }
}

/*
	Run this program as follows:

	==> java MultiCatch

	==> java MultiCatch test

*/

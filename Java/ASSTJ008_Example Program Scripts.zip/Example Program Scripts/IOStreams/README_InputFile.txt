# +----------------------------------------------------------------------------+
# | FILE      : README_InputFile.txt                                           |
# | AUTHOR    : Jeffrey Hunter                                                 |
# | WEB       : http://www.iDevelopment.info                                   |
# | CATEGORY  : Java Programming                                               |
# | SUBJECT   : I/O                                                            |
# +----------------------------------------------------------------------------+

I. INTRODUCTION

   The following file can be used as an input text file to Java programs in
   the I/O section.


// -----------------------------------------------------------------------------
// ReadFromConsole.java
// -----------------------------------------------------------------------------

import java.io.*;

/**
 * -----------------------------------------------------------------------------
 * Used to test the Java I/O package to read from the console.
 * -----------------------------------------------------------------------------
 */

public class ReadIntFromConsole {


    private static void doReadIntFromConsole() {

        String inLine = null;
        int    checkInteger  = 0;

        try {
            BufferedReader inStream = new BufferedReader (
                                          new InputStreamReader(System.in)
                                      );
            System.out.print("Enter a valid Integer and hit <ENTER>: ");
            inLine = inStream.readLine();
            checkInteger    = Integer.parseInt(inLine);

        } catch (NumberFormatException nfe) {
            System.out.println("You did not enter a valid Integer: " + inLine);
            return;
        } catch (IOException e) {
            System.out.println("IOException: " + e);
            return;
        }

        System.out.println("You entered a valid Integer: " + checkInteger);

    }


    /**
     * Sole entry point to the class and application.
     * @param args Array of String arguments.
     */
    public static void main(String[] args) {
        doReadIntFromConsole();
    }

}


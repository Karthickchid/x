// -----------------------------------------------------------------------------
// DetermineFileDirExists.java
// -----------------------------------------------------------------------------

import java.io.File;


/**
 * -----------------------------------------------------------------------------
 * This program demonstrates how to determine if a File or Directory exists
 * on the filesystem.
 * -----------------------------------------------------------------------------
 */

public class DetermineFileDirExists {

    private static void doTest() {

        // Create a File object
        File file1 = new File("README_InputFile.txt");
        File file2 = new File("BlaBlaBla.txt");

        boolean b = file1.exists();
        System.out.println();
        System.out.println("Does File/Dir " + file1 + " exist? (" + b + ")\n");

        b = file2.exists();
        System.out.println();
        System.out.println("Does File/Dir " + file2 + " exist? (" + b + ")\n");


    }


    /**
     * Sole entry point to the class and application.
     * @param args Array of String arguments.
     */
    public static void main(String[] args) {
        doTest();
    }

}

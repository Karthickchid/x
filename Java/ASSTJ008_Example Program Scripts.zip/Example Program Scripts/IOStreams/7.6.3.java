
public class TestLogger {

    public static void main (String[] args) {

        int c = 0;
        final int MAX = 90000000;

        Logger1 log = new Logger1("TestLogger.log");
        log.start();
        log.writeln("main : < Starting with counter at " + c);

        for (int i = 0; i < MAX; i++) {
            if ( (i % 10000000) == 0) {
                c += 1;
            }
        }

        log.writeln("main : > Ending main with counter at " + c);
        log.stop();

    }

}

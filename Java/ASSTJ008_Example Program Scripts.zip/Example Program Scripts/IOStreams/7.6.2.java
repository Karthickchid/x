// -----------------------------------------------------------------------------
// WritingToFile.java
// -----------------------------------------------------------------------------

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

/**
 * -----------------------------------------------------------------------------
 * This program demonstrates how to write to a file. If the file does not
 * already exist, it is automatically created.
 * -----------------------------------------------------------------------------
 */

public class WritingToFile {

    private static void doWrite() {

        try {
        
            String fileName = "WritingToFile.out";

            BufferedWriter out = new BufferedWriter(new FileWriter(fileName));
            
            out.write("+---------- Testing output to a file ----------+");

            // Print several new line characters. I use two styles here.
            out.write(0x0A);
            out.write("\n");
            
            out.write("+---------- Testing output to a file ----------+");

            out.close();

        } catch (IOException e) {

            System.out.println("IOException:");
            e.printStackTrace();

        }

    }


    /**
     * Sole entry point to the class and application.
     * @param args Array of String arguments.
     */
    public static void main(String[] args) {
        doWrite();
    }

}

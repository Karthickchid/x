// -----------------------------------------------------------------------------
// AbsoluteRelativePath.java
// -----------------------------------------------------------------------------

import java.io.File;


/**
 * -----------------------------------------------------------------------------
 * This program demonstrates how to get an Absolute Filename Path from a
 * Relative Filename Path. Note that the filename (in the case of this example:
 * README_InputFile.txt) does not have to exist on the filesystem.
 * -----------------------------------------------------------------------------
 */

public class AbsoluteRelativePath {

    private static void doConversion() {

        // Create a File object
        File fileName = new File("README_InputFile.txt");
        System.out.println();
        System.out.println("Original Filename              = " + fileName + "\n");

        fileName = fileName.getAbsoluteFile();
        System.out.println("Absolute Filename              = " + fileName + "\n");

        fileName = new File("dir" + File.separatorChar + "README_InputFile.txt");
        fileName = fileName.getAbsoluteFile();
        System.out.println("Absolute Filename with \"dir\"   = " + fileName + "\n");

        fileName = new File(".." + File.separatorChar + "README_InputFile.txt");
        fileName = fileName.getAbsoluteFile();
        System.out.println("Absolute Filename with \"..\"    = " + fileName + "\n");

    }


    /**
     * Sole entry point to the class and application.
     * @param args Array of String arguments.
     */
    public static void main(String[] args) {
        doConversion();
    }

}

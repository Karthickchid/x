// -----------------------------------------------------------------------------
// ParentsOfFilenamePath.java
// -----------------------------------------------------------------------------

import java.io.File;


/**
 * -----------------------------------------------------------------------------
 * This program demonstrates how to get the parents of a filename path. Note
 * that the filename (in the case of this example: README_InputFile.txt) does 
 * not have to exist on the filesystem.
 * -----------------------------------------------------------------------------
 */

public class ParentsOfFilenamePath {

    private static void doTest() {

        // Get the parent of a relative filename path
        File fileName = new File("README_InputFile.txt");
        String parentPath = fileName.getParent();
        File   parentDir  = fileName.getParentFile();
        System.out.println();
        System.out.println("Original Filename   = " + fileName);
        System.out.println("Parent Path         = " + parentPath);
        System.out.println("Parent Directory    = " + parentDir);

        // Get the parents of an absolute filename path
        fileName   = new File("/u01/app/oracle/README_InputFile.txt");
        parentPath = fileName.getParent();
        parentDir  = fileName.getParentFile();
        System.out.println();
        System.out.println("Original Filename   = " + fileName);
        System.out.println("Parent Path         = " + parentPath);
        System.out.println("Parent Directory    = " + parentDir);

        // The remaining portion of the code will keep stripping out
        // the parent from each filename path.
        System.out.println();
        System.out.println("Original Filename   = " + parentPath);
        parentPath = parentDir.getParent();
        parentDir  = parentDir.getParentFile();
        System.out.println("Parent Path         = " + parentPath);
        System.out.println("Parent Directory    = " + parentDir);

        System.out.println();
        System.out.println("Original Filename   = " + parentPath);
        parentPath = parentDir.getParent();
        parentDir  = parentDir.getParentFile();
        System.out.println("Parent Path         = " + parentPath);
        System.out.println("Parent Directory    = " + parentDir);

        System.out.println();
        System.out.println("Original Filename   = " + parentPath);
        parentPath = parentDir.getParent();
        parentDir  = parentDir.getParentFile();
        System.out.println("Parent Path         = " + parentPath);
        System.out.println("Parent Directory    = " + parentDir);

        System.out.println();
        System.out.println("Original Filename   = " + parentPath);
        parentPath = parentDir.getParent();
        parentDir  = parentDir.getParentFile();
        System.out.println("Parent Path         = " + parentPath);
        System.out.println("Parent Directory    = " + parentDir);

    }


    /**
     * Sole entry point to the class and application.
     * @param args Array of String arguments.
     */
    public static void main(String[] args) {
        doTest();
    }

}

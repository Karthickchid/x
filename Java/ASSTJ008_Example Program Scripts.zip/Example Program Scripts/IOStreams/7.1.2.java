// -----------------------------------------------------------------------------
// CreateDirectory.java
// -----------------------------------------------------------------------------

import java.io.File;


/**
 * -----------------------------------------------------------------------------
 * This program demonstrates how to create a directory.
 * -----------------------------------------------------------------------------
 */

public class CreateDirectory {

    private static void doCreateDir() {

        // Create a directory; all ancestor directories must exist if you
        // use an absolute path. If you are using a relative path, the 
        // directory will be created in the current working directory.
        String newDir = "new_dir";
        boolean success = (new File(newDir)).mkdir();

        if (success) {
            System.out.println("Successfully created directory: " + newDir);
        } else {
            System.out.println("Failed to create directory: " + newDir);
        }

        // Create a directory; all non-existent ancestor directories are
        // automatically created.
        newDir = "c:/export/home/jeffreyh/new_dir1/new_dir2/new_dir3";
        success = (new File(newDir)).mkdirs();

        if (success) {
            System.out.println("Successfully created directory: " + newDir);
        } else {
            System.out.println("Failed to create directory: " + newDir);
        }

    }


    /**
     * Sole entry point to the class and application.
     * @param args Array of String arguments.
     */
    public static void main(String[] args) {
        doCreateDir();
    }

}

// -----------------------------------------------------------------------------
// DetermineFileOrDir.java
// -----------------------------------------------------------------------------

import java.io.File;


/**
 * -----------------------------------------------------------------------------
 * This program demonstrates how to determine if a filename path is a File or
 * a Directory.
 * -----------------------------------------------------------------------------
 */

public class DetermineFileOrDir {

    private static void doTest() {

        // Create a File object
        File fileName = new File("README_InputFile.txt");
        System.out.println();
        System.out.println("Original Filename = " + fileName);

        boolean isDir = fileName.isDirectory();

        System.out.println("Is " + fileName + " a directory? (" + isDir + ")");

        // Keep in mind that the following pathSeparator character '/' can be 
        // used in both MS Windows and UNIX environments. You could have also
        // used:
        //   fileName = new File("c:\\export\\home\\jeffreyh\\JDeveloper\\IsrvWorkspace\\JavaProgramming\\src\\io\\FilenamesPathnames");
        fileName = new File("c:/export/home/jeffreyh/JDeveloper/IsrvWorkspace/JavaProgramming/src/io/FilenamesPathnames");

        isDir = fileName.isDirectory();

        System.out.println("Is " + fileName + " a directory? (" + isDir + ")");

    }


    /**
     * Sole entry point to the class and application.
     * @param args Array of String arguments.
     */
    public static void main(String[] args) {
        doTest();
    }

}

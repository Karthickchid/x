// -----------------------------------------------------------------------------
// RenamingFileOrDir.java
// -----------------------------------------------------------------------------

import java.io.File;


/**
 * -----------------------------------------------------------------------------
 * This program demonstrates how to rename a File or Directory.
 * -----------------------------------------------------------------------------
 */

public class RenamingFileOrDir {

    private static void doRename() {

        // A File (or Directory) with the old name
        File file1 = new File("OldFile.txt");
        System.out.println("File1 = " + file1);

        // A File (or Directory) with the new name
        File file2 = new File("NewFile.txt");
        System.out.println("File2 = " + file2);

        // Rename File (or Directory)
        boolean success = file1.renameTo(file2);

        if (success) {
            System.out.println("File was successfully renamed.\n");
        } else {
            System.out.println("File was not successfully renamed.\n");
        }

    }


    /**
     * Sole entry point to the class and application.
     * @param args Array of String arguments.
     */
    public static void main(String[] args) {
        doRename();
    }

}

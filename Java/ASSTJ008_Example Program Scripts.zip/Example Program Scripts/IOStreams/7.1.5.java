// -----------------------------------------------------------------------------
// DeletingFile.java
// -----------------------------------------------------------------------------

import java.io.File;


/**
 * -----------------------------------------------------------------------------
 * This program demonstrates how to delete a File or Directory from disk.
 * -----------------------------------------------------------------------------
 */

public class DeletingFile {

    private static void doCreate() {

        // Create a File object
        File file = new File("NewFile.txt");

        boolean success = file.delete();

        if (success) {
            System.out.println("File was successfully deleted.\n");
        } else {
            System.out.println("File was not successfully deleted.\n");
        }

    }


    /**
     * Sole entry point to the class and application.
     * @param args Array of String arguments.
     */
    public static void main(String[] args) {
        doCreate();
    }

}

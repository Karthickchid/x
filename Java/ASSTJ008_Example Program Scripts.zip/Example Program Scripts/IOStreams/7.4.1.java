// -----------------------------------------------------------------------------
// GetWorkingDir.java
// -----------------------------------------------------------------------------


/**
 * -----------------------------------------------------------------------------
 * This program demonstrates how to get the current working directory. The 
 * working directory is the location in the file system from where the "java"
 * command was invoked.
 * -----------------------------------------------------------------------------
 */

public class GetWorkingDir {

    private static void doGetDir() {

        String curDir = System.getProperty("user.dir");
        
        System.out.println("\nThe current working directory is:");
        System.out.println("  - " + curDir);

    }


    /**
     * Sole entry point to the class and application.
     * @param args Array of String arguments.
     */
    public static void main(String[] args) {
        doGetDir();
    }

}

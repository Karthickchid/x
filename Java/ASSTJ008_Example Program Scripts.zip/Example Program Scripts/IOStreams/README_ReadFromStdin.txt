# +----------------------------------------------------------------------------+
# | FILE      : README_ReadFromStdin.txt                                       |
# | AUTHOR    : Jeffrey Hunter                                                 |
# | WEB       : http://www.iDevelopment.info                                   |
# | CATEGORY  : Java Programming                                               |
# | SUBJECT   : I/O                                                            |
# +----------------------------------------------------------------------------+

I. INTRODUCTION

   The following file should only be used as an input text file to the Java 
   program ReadFromStdin.java.

II. Usage

  % java ReadFromStdin < readme.txt

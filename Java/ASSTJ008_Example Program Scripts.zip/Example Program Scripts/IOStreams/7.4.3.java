// -----------------------------------------------------------------------------
// ListFileSystemRoots.java
// -----------------------------------------------------------------------------

import java.io.File;


/**
 * -----------------------------------------------------------------------------
 * This program demonstrates how to list the file system root directories. UNIX
 * file systems have a single root , '/' while on Windows, each drive is a root.
 * For example, the C drive is represented by the root 'C:\'.
 * -----------------------------------------------------------------------------
 */

public class ListFileSystemRoots {

    private static void doListRoots() {

        File[] roots = File.listRoots();

        for (int i=0; i<roots.length; i++) {
            System.out.println("Root[" + i + "] = " + roots[i]);
        }

    }


    /**
     * Sole entry point to the class and application.
     * @param args Array of String arguments.
     */
    public static void main(String[] args) {
        doListRoots();
    }

}

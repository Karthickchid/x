// -----------------------------------------------------------------------------
// AppendingToFile.java
// -----------------------------------------------------------------------------

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

/**
 * -----------------------------------------------------------------------------
 * This program demonstrates how to append to a file. If the file does not
 * already exist, it is automatically created.
 * 
 * This example will use the same file that was created and written to by the 
 * WritingToFile.java program.
 * -----------------------------------------------------------------------------
 */

public class AppendingToFile {

    private static void doAppend() {

        try {
        
            String fileName = "WritingToFile.out";

            BufferedWriter out = new BufferedWriter(new FileWriter(fileName, true));

            out.write(0x0A); 
            out.write("+---------- Testing output (append) to a file ----------+");

            // Print several new line characters. I use two styles here.
            out.write(0x0A);
            out.write("\n");
            
            out.write("+---------- Testing output (append) to a file ----------+");

            out.close();

        } catch (IOException e) {

            System.out.println("IOException:");
            e.printStackTrace();

        }

    }


    /**
     * Sole entry point to the class and application.
     * @param args Array of String arguments.
     */
    public static void main(String[] args) {
        doAppend();
    }

}

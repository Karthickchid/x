// -----------------------------------------------------------------------------
// TraverseDirectory.java
// -----------------------------------------------------------------------------

import java.io.File;


/**
 * -----------------------------------------------------------------------------
 * This program demonstrates how to traverse a directory.
 * -----------------------------------------------------------------------------
 */

public class TraverseDirectory {

    private static void processDir(File dir) {

        System.out.print( (dir.isDirectory() ? "[D] : " : "[F] : "));
        System.out.println(dir);

    }

    private static void traverse(File dir) {

        processDir(dir);

        if (dir.isDirectory()) {
            String[] children = dir.list();
            for (int i=0; i<children.length; i++) {
                traverse(new File(dir, children[i]));
            }
        }

    }


    /**
     * Sole entry point to the class and application.
     * @param args Array of String arguments.
     */
    public static void main(String[] args) {
        traverse(new File("new_dir"));
    }

}
